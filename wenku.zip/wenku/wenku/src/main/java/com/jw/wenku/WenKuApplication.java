package com.jw.wenku;

import org.mybatis.spring.annotation.MapperScan;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@MapperScan("com.jw.wenku.mapper")
@ServletComponentScan
@EnableScheduling
@EnableAsync
public class WenKuApplication {

    private static final Logger LOG = LoggerFactory.getLogger(WenKuApplication.class);

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(WenKuApplication.class);
        ConfigurableEnvironment env = app.run(args).getEnvironment();

        LOG.info("项目启动成功！");
        LOG.info("地址：\thttp://127.0.0.1:{}", env.getProperty("server.port"));
    }
}