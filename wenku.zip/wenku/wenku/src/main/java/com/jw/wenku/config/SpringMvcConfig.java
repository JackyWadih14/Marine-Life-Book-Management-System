package com.jw.wenku.config;

import com.jw.wenku.interceptor.LoginInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import javax.annotation.Resource;

@Configuration
public class SpringMvcConfig implements WebMvcConfigurer {

    @Resource
    private RedisTemplate redisTemplate;

    @Bean
    public LoginInterceptor loginInterceptor() {
        LoginInterceptor interceptor = new LoginInterceptor();
        interceptor.setRedisTemplate(redisTemplate);
        return interceptor;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(loginInterceptor())
                .addPathPatterns("/**")
                .excludePathPatterns(
                        "/doc/vote/**",
                        "/doc/info/**",
                        "/doc/all/**",
                        "/doc/list",
                        "/doc/save",
                        "/doc/remove",
                        "/doc/delete/**",
                        "/content/findContent/**",
                        "/ebook/list",
                        "/ebook/save",
                        "/ebook/update/**",
                        "/ebook/delete/**",
                        "/ebookSnapshot/**",
                        "/category/all",
                        "/category/save",
                        "/category/delete/**",
                        "/user/delete/**",
                        "/user/login",
                        "/user/list",
                        "/user/save",
                        "/user/resetPassword"
                );
    }
}