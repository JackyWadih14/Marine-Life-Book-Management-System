package com.jw.wenku.config.xss;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.util.AntPathMatcher;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Component
@WebFilter(urlPatterns = "/*")
@Order(1)
public class XssFilter implements Filter {

    private static final Logger logger = LoggerFactory.getLogger(XssFilter.class);

    private final List<String> excludeUrlList;
    private final AntPathMatcher pathMatcher = new AntPathMatcher();

    public XssFilter(@Value("${xss.exclude-urls:}") String[] excludeUrls) {
        // Java 8 兼容处理：若数组为 null 或长度为 0，则使用空列表
        if (excludeUrls == null || excludeUrls.length == 0) {
            this.excludeUrlList = Collections.emptyList();
        } else {
            this.excludeUrlList = Arrays.asList(excludeUrls);
        }
        logger.info("XssFilter initialized, exclude URLs: {}", this.excludeUrlList);
    }

    @Override
    public void init(FilterConfig filterConfig) {
        // 初始化日志
        logger.info("XssFilter init");
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        if (!(request instanceof HttpServletRequest)) {
            chain.doFilter(request, response);
            return;
        }

        HttpServletRequest httpRequest = (HttpServletRequest) request;
        String uri = httpRequest.getRequestURI();

        boolean isExcluded = excludeUrlList.stream()
                .anyMatch(pattern -> pathMatcher.match(pattern, uri));

        if (isExcluded) {
            logger.debug("XssFilter skipped for URI: {}", uri);
            chain.doFilter(request, response);
            return;
        }

        // 使用包装类过滤
        XssHttpServletRequestWrapper wrapper = new XssHttpServletRequestWrapper(httpRequest);
        chain.doFilter(wrapper, response);
    }

    @Override
    public void destroy() {
        logger.info("XssFilter destroyed");
    }
}