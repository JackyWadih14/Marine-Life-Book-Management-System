package com.jw.wenku.config.xss;

import org.apache.commons.lang3.StringEscapeUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import java.util.HashMap;
import java.util.Map;

/**
 * XSS 过滤请求包装类
 * 对请求参数和请求体中的 HTML 标签进行转义，防止 XSS 攻击
 */
public class XssHttpServletRequestWrapper extends HttpServletRequestWrapper {

    private static final Logger logger = LoggerFactory.getLogger(XssHttpServletRequestWrapper.class);

    public XssHttpServletRequestWrapper(HttpServletRequest request) {
        super(request);
    }

    /**
     * 对单个参数值进行过滤
     */
    @Override
    public String getParameter(String name) {
        String value = super.getParameter(name);
        if (value == null) {
            return null;
        }
        return cleanXSS(value);
    }

    /**
     * 对参数值数组进行过滤
     */
    @Override
    public String[] getParameterValues(String name) {
        String[] values = super.getParameterValues(name);
        if (values == null || values.length == 0) {
            return values;
        }
        String[] cleaned = new String[values.length];
        for (int i = 0; i < values.length; i++) {
            cleaned[i] = cleanXSS(values[i]);
        }
        return cleaned;
    }

    /**
     * 对整个参数 Map 进行过滤
     */
    @Override
    public Map<String, String[]> getParameterMap() {
        Map<String, String[]> originalMap = super.getParameterMap();
        if (originalMap == null || originalMap.isEmpty()) {
            return originalMap;
        }
        Map<String, String[]> filteredMap = new HashMap<>(originalMap.size());
        for (Map.Entry<String, String[]> entry : originalMap.entrySet()) {
            String key = entry.getKey();
            String[] values = entry.getValue();
            if (values != null) {
                String[] cleaned = new String[values.length];
                for (int i = 0; i < values.length; i++) {
                    cleaned[i] = cleanXSS(values[i]);
                }
                filteredMap.put(key, cleaned);
            } else {
                filteredMap.put(key, null);
            }
        }
        return filteredMap;
    }

    /**
     * 对请求体内容进行过滤（通过 InputStream 读取时需重写 getInputStream）
     * 注意：对于 JSON 请求体，需要在 Controller 中使用 @RequestBody 时，
     * 可以通过自定义 HttpMessageConverter 或 AOP 处理，此处不拦截。
     * 若需拦截请求体，可重写 getInputStream 和 getReader，
     * 但实现较为复杂，通常由 JSON 序列化框架处理。
     * 为了简便，我们在此不重写，仅对参数进行过滤。
     */

    /**
     * XSS 过滤核心方法：转义 HTML 特殊字符
     */
    private String cleanXSS(String value) {
        // 使用 Apache Commons Lang 的转义方法，也可自行实现
        // 如果不想引入 commons-lang3，可自行替换为简单的替换
        String escaped = StringEscapeUtils.escapeHtml4(value);
        // 可选：额外过滤 javascript: 等协议
        // escaped = escaped.replaceAll("(?i)javascript:", "");
        // escaped = escaped.replaceAll("(?i)on[a-z]+\\s*=", "");
        logger.debug("XSS cleaned: {}", escaped);
        return escaped;
    }
}