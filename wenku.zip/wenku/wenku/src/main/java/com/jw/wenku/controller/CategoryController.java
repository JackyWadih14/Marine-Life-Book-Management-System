package com.jw.wenku.controller;

import com.jw.wenku.req.CategorySaveReq;
import com.jw.wenku.resp.CategoryQueryResp;
import com.jw.wenku.resp.CommonResp;
import com.jw.wenku.service.ICategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/category")
public class CategoryController {

    @Autowired
    private ICategoryService categoryService;

    @GetMapping("/all")
    public CommonResp<List<CategoryQueryResp>> all() {
        List<CategoryQueryResp> list = categoryService.all();
        return new CommonResp<>(true, "查询成功", list);
    }

    @PostMapping("/save")
    public CommonResp<Void> save(@Valid @RequestBody CategorySaveReq req) {
        categoryService.save(req);
        return new CommonResp<>(true, "操作成功", null);
    }

    @DeleteMapping("/delete/{id}")
    public CommonResp<Void> delete(@PathVariable Long id) {
        categoryService.delete(id);
        return new CommonResp<>(true, "删除成功", null);
    }
}