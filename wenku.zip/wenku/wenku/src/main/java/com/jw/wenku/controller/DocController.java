package com.jw.wenku.controller;

import com.jw.wenku.req.DocQueryReq;
import com.jw.wenku.req.DocSaveReq;
import com.jw.wenku.resp.CommonResp;
import com.jw.wenku.resp.DocQueryResp;
import com.jw.wenku.resp.PageResp;
import com.jw.wenku.service.IDocService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/doc")
public class DocController {

    @Autowired
    private IDocService docService;

    @GetMapping("/all")
    public CommonResp<List<DocQueryResp>> all() {
        List<DocQueryResp> list = docService.all();
        return new CommonResp<>(true, "查询成功", list);
    }

    @GetMapping("/all/{ebookId}")
    public CommonResp allByEbookId(@PathVariable Long ebookId) {
        CommonResp<List<DocQueryResp>> resp = new CommonResp<>();
        List<DocQueryResp> list = docService.allbyEbookId(ebookId);
        resp.setContent(list);
        return resp;
    }

    @GetMapping("/list")
    public CommonResp<PageResp<DocQueryResp>> list(@Valid DocQueryReq req) {
        PageResp<DocQueryResp> pageResp = docService.listByname(req);
        return new CommonResp<>(true, "查询成功", pageResp);
    }

    @PostMapping("/save")
    public CommonResp<Void> save(@Valid @RequestBody DocSaveReq req) {
        docService.save(req);
        return new CommonResp<>(true, "操作成功", null);
    }

    @DeleteMapping("/delete/{id}")
    public CommonResp<Void> delete(@PathVariable Long id) {
        docService.delete(id);
        return new CommonResp<>(true, "删除成功", null);
    }

    @GetMapping("/remove")
    public CommonResp delete(@RequestParam("ids") List<Long> ids) {
        CommonResp resp = new CommonResp<>(true,"删除成功",null);

        docService.delete(ids);
        return resp;
    }

    @GetMapping("/vote/{id}")
    public CommonResp vote(@PathVariable Long id) {
        CommonResp commonResp = new CommonResp();
        docService.vote(id);
        return commonResp;
    }

    @GetMapping("/info/{id}")
    public CommonResp<DocQueryResp> info(@PathVariable Long id) {
        CommonResp<DocQueryResp> resp = new CommonResp<>();
        DocQueryResp doc = docService.info(id);
        resp.setContent(doc);
        return resp;
    }
}