package com.jw.wenku.controller;

import com.jw.wenku.req.EbookQueryReq;
import com.jw.wenku.req.EbookSaveReq;
import com.jw.wenku.resp.CommonResp;
import com.jw.wenku.resp.EbookQueryResp;
import com.jw.wenku.resp.PageResp;
import com.jw.wenku.service.IEbookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/ebook")
public class EbookController {

    @Autowired
    private IEbookService ebookService;

    @RequestMapping("/list")
    public CommonResp list(@Valid EbookQueryReq req) {
        PageResp<EbookQueryResp> pageResp = ebookService.getBookList(req);
        return new CommonResp<>(true, "查询成功", pageResp);
    }

    @PostMapping("/save")
    public CommonResp save(@Valid @RequestBody EbookSaveReq req) {
        ebookService.save(req);
        return new CommonResp<>(true, "保存成功", null);
    }

    @PutMapping("/update/{id}")
    public CommonResp update(@PathVariable Long id, @Valid @RequestBody EbookSaveReq req) {
        req.setId(id);
        ebookService.save(req);
        return new CommonResp<>(true, "更新成功", null);
    }

    @DeleteMapping("/delete/{id}")
    public CommonResp delete(@PathVariable Long id) {
        ebookService.removeById(id);
        return new CommonResp<>(true, "删除成功", null);
    }
}