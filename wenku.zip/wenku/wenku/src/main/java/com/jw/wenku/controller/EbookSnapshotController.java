package com.jw.wenku.controller;

import com.jw.wenku.resp.CommonResp;
import com.jw.wenku.resp.StatisticResp;
import com.jw.wenku.service.IEbookSnapshotService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 * 电子书快照 前端控制器
 * </p>
 *
 * @author JW
 * @since 2026-06-16
 */
@RestController
@RequestMapping("/ebookSnapshot")
public class EbookSnapshotController {

    @Resource
    private IEbookSnapshotService ebookSnapshotService;

    /**
     * 获取统计数据（总阅读、总点赞、今日阅读、今日点赞、预计今日阅读、增长率等）
     * @return CommonResp 包含 StatisticResp 列表
     */
    @GetMapping("/getStatistic")
    public CommonResp<List<StatisticResp>> getStatistic() {
        List<StatisticResp> statisticResp = ebookSnapshotService.getStatistic();
        return new CommonResp<>(true, "查询成功", statisticResp);
    }

    @GetMapping("/get30Statistic")
    public CommonResp get30Statistic() {
        List<StatisticResp> statisticResp = ebookSnapshotService.get30Statistic();
        CommonResp<List<StatisticResp>> commonResp = new CommonResp<>();
        commonResp.setContent(statisticResp);
        return commonResp;
    }

}