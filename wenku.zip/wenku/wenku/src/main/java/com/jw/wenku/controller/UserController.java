package com.jw.wenku.controller;

import com.alibaba.fastjson.JSONObject;
import com.jw.wenku.req.UserLoginReq;
import com.jw.wenku.req.UserQueryReq;
import com.jw.wenku.req.UserResetPasswordReq;
import com.jw.wenku.req.UserSaveReq;
import com.jw.wenku.resp.CommonResp;
import com.jw.wenku.resp.PageResp;
import com.jw.wenku.resp.UserLoginResp;
import com.jw.wenku.resp.UserQueryResp;
import com.jw.wenku.service.IUserService;
import com.jw.wenku.util.SnowFlake;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.concurrent.TimeUnit;

/**
 * <p>
 * 用户 前端控制器
 * </p>
 *
 * @author JW
 * @since 2026-06-16
 */
@RestController
@RequestMapping("/user")
public class UserController {

    private static final Logger LOG = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private IUserService userService;

    @Autowired
    private SnowFlake snowFlake;

    @Autowired
    private RedisTemplate<String, String> redisTemplate;

    /**
     * 用户登录
     */
    @PostMapping("/login")
    public CommonResp<UserLoginResp> login(@Valid @RequestBody UserLoginReq req) {
        // 密码 MD5 加密（与前端加密方式一致）
        req.setPassword(DigestUtils.md5DigestAsHex(req.getPassword().getBytes()));
        CommonResp<UserLoginResp> resp = new CommonResp<>();
        UserLoginResp userLoginResp = userService.login(req);

        // 生成 Token（雪花算法）
        Long token = snowFlake.nextId();
        LOG.info("生成单点登录 token：{}，并放入 Redis 中", token);
        userLoginResp.setToken(token.toString());

        // 存入 Redis，过期时间 24 小时
        redisTemplate.opsForValue().set(
                token.toString(),
                JSONObject.toJSONString(userLoginResp),
                3600 * 24,
                TimeUnit.SECONDS
        );

        resp.setContent(userLoginResp);
        return resp;
    }

    @GetMapping("/logout/{token}")
    public CommonResp logout(@PathVariable String token) {
        CommonResp resp = new CommonResp<>();
        redisTemplate.delete(token);
        LOG.info("从redis中删除token: {}", token);
        return resp;
    }

    /**
     * 分页查询用户列表
     */
    @GetMapping("/list")
    public CommonResp<PageResp<UserQueryResp>> list(@Valid UserQueryReq req) {
        PageResp<UserQueryResp> pageResp = userService.listByname(req);
        return new CommonResp<>(true, "查询成功", pageResp);
    }

    /**
     * 新增或更新用户
     */
    @PostMapping("/save")
    public CommonResp<Void> save(@Valid @RequestBody UserSaveReq req) {
        // 密码 MD5 加密（前端已加密，此处可选；但为保证兼容，可保留或移除）
        // 若前端已加密，则此处无需再加密；若前端明文，则需加密。
        // 当前保留以兼容可能的前端明文场景，但若前端已加密，此处会二次加密导致错误。
        // 建议：根据实际情况决定是否保留这行。
        // req.setPassword(DigestUtils.md5DigestAsHex(req.getPassword().getBytes()));
        userService.save(req);
        return new CommonResp<>(true, "操作成功", null);
    }

    /**
     * 删除用户（根据ID）
     */
    @DeleteMapping("/delete/{id}")
    public CommonResp<Void> delete(@PathVariable Long id) {
        userService.delete(id);
        return new CommonResp<>(true, "删除成功", null);
    }

    /**
     * 重置密码
     */
    @PostMapping("/resetPassword")
    public CommonResp<Void> resetPassword(@Valid @RequestBody UserResetPasswordReq req) {
        // 密码 MD5 加密（前端已加密，此处可移除）
        // req.setPassword(DigestUtils.md5DigestAsHex(req.getPassword().getBytes()));
        userService.resetPassword(req);
        return new CommonResp<>(true, "密码重置成功", null);
    }
}