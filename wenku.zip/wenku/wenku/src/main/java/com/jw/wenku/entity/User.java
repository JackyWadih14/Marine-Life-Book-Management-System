package com.jw.wenku.entity;

import lombok.Data;

@Data
public class User {
    private Long id;
    private String loginName;
    private String name;
    private String password;
    private String role;
}