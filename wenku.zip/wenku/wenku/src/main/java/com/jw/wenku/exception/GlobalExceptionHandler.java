package com.jw.wenku.exception;

import com.jw.wenku.resp.CommonResp;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger LOG = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(BusinessException.class)
    public CommonResp<Void> handleBusinessException(BusinessException e) {
        LOG.warn("业务异常: {}", e.getMessage());
        CommonResp<Void> resp = new CommonResp<>();
        resp.setSuccess(false);
        resp.setMessage(e.getMessage());
        return resp;
    }

    @ExceptionHandler(Exception.class)
    public CommonResp<Void> handleException(Exception e) {
        LOG.error("系统异常", e);
        CommonResp<Void> resp = new CommonResp<>();
        resp.setSuccess(false);
        resp.setMessage("系统异常，请联系管理员");
        return resp;
    }
}