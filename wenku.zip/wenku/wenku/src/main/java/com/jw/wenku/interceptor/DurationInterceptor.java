package com.jw.wenku.interceptor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 请求耗时统计拦截器
 * 用于记录每个请求的处理耗时
 */
//@Component
public class DurationInterceptor implements HandlerInterceptor {

    private static final Logger LOG = LoggerFactory.getLogger(DurationInterceptor.class);

    // 执行 Controller 之前
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        // 打印请求信息
        LOG.info("------------- 请求开始 -------------");
        LOG.info("请求地址: {} {}", request.getRequestURL().toString(), request.getMethod());
        LOG.info("远程地址: {}", request.getRemoteAddr());

        // 记录开始时间
        long startTime = System.currentTimeMillis();
        request.setAttribute("requestStartTime", startTime);
        return true;
    }

    // 执行 Controller 之后（渲染视图之前）
    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
                           ModelAndView modelAndView) throws Exception {
        // 可以在这里添加一些后处理逻辑，但不建议在这里计算耗时
        // 因为如果发生异常，postHandle 不会被调用
    }

    // 整个请求完成后（包括视图渲染，或发生异常）
    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        Long startTime = (Long) request.getAttribute("requestStartTime");
        if (startTime != null) {
            long elapsed = System.currentTimeMillis() - startTime;
            LOG.info("------------- 请求结束 耗时：{} ms -------------", elapsed);
        }
    }
}