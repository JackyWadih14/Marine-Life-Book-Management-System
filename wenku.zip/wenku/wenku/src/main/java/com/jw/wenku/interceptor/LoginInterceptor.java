package com.jw.wenku.interceptor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class LoginInterceptor implements HandlerInterceptor {

    private static final Logger LOG = LoggerFactory.getLogger(LoginInterceptor.class);


    private RedisTemplate redisTemplate;

    public void setRedisTemplate(RedisTemplate redisTemplate) {
        this.redisTemplate = redisTemplate;
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        // OPTIONS请求不做校验
        if (request.getMethod().toUpperCase().equals("OPTIONS")) {
            return true;
        }

        String uri = request.getRequestURI();
        LOG.info("LoginInterceptor URI: {}", uri);

        // ========== 白名单 ==========
        if (uri.startsWith("/doc/vote/") ||
                uri.startsWith("/error") ||
                uri.startsWith("/doc/info/") ||
                uri.startsWith("/doc/all/") ||
                uri.startsWith("/doc/list") ||
                uri.startsWith("/doc/save") ||
                uri.startsWith("/doc/remove") ||
                uri.startsWith("/doc/delete/") ||
                uri.startsWith("/content/findContent/") ||
                uri.startsWith("/ebook/list") ||
                uri.startsWith("/ebook/save") ||
                uri.startsWith("/ebook/update/") ||
                uri.startsWith("/ebook/delete/") ||
                uri.startsWith("/category/all") ||
                uri.startsWith("/category/save") ||
                uri.startsWith("/category/delete/") ||
                uri.startsWith("/user/delete/") ||
                uri.startsWith("/user/login") ||
                uri.startsWith("/user/list") ||
                uri.startsWith("/user/save") ||
                uri.startsWith("/user/resetPassword")) {
            LOG.info("白名单放行：{}", uri);
            return true;
        }

        // 获取 header 的 token 参数
        String token = request.getHeader("token");
        LOG.info("登录校验开始，token：{}", token);
        if (token == null || token.isEmpty()) {
            LOG.info("token为空，请求被拦截");
            response.setStatus(HttpStatus.UNAUTHORIZED.value());
            return false;
        }
        Object object = redisTemplate.opsForValue().get(token);
        if (object == null) {
            LOG.warn("token无效，请求被拦截");
            response.setStatus(HttpStatus.UNAUTHORIZED.value());
            return false;
        } else {
            LOG.info("已登录：{}", object);
            return true;
        }
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        long startTime = (Long) request.getAttribute("requestStartTime");
        LOG.info("------------- LoginInterceptor 结束 耗时：{} ms -------------", System.currentTimeMillis() - startTime);
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
//        LOG.info("LogInterceptor 结束");
    }
}