package com.jw.wenku.job;

import com.jw.wenku.service.IEbookSnapshotService;
import com.jw.wenku.util.SnowFlake;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * 电子书快照定时任务
 * 每分钟执行一次，生成当前电子书的阅读数、点赞数快照
 */
@Component
public class EbookSnapshotJob {

    private static final Logger LOG = LoggerFactory.getLogger(EbookSnapshotJob.class);

    @Resource
    private IEbookSnapshotService ebookSnapshotService;

    @Resource
    private SnowFlake snowFlake;

    /**
     * 定时生成电子书快照
     * cron 表达式：每分钟执行一次
     * 若上一次执行未完成，下一次执行会顺延，错过的时间点不再补执行
     */
    @Scheduled(cron = "0 0/1 * * * ?")
    public void doSnapshot() {
        // 生成日志流水号，便于链路追踪
        MDC.put("LOG_ID", String.valueOf(snowFlake.nextId()));

        LOG.info("生成今日电子书快照开始");
        long start = System.currentTimeMillis();

        try {
            ebookSnapshotService.genSnapshot();
            LOG.info("生成今日电子书快照结束，耗时：{} ms", System.currentTimeMillis() - start);
        } catch (Exception e) {
            LOG.error("生成电子书快照失败", e);
        } finally {
            // 清除 MDC，避免内存泄漏
            MDC.remove("LOG_ID");
        }
    }
}