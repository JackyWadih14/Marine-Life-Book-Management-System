package com.jw.wenku.mapper;

import com.jw.wenku.entity.Content;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author JW
 * @since 2026-06-16
 */
public interface ContentMapper extends BaseMapper<Content> {

}
