package com.jw.wenku.mapper;

import com.jw.wenku.entity.Doc;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author JW
 * @since 2026-06-16
 */
public interface DocMapper extends BaseMapper<Doc> {

    void increaseViewCount(Long id);

    void increaseVoteCount(Long id);

    void updateEbookInfo();
}
