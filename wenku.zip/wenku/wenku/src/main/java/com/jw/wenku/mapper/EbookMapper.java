package com.jw.wenku.mapper;

import com.jw.wenku.entity.Ebook;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 电子书 Mapper 接口
 * </p>
 *
 * @author JW
 * @since 2026-06-16
 */
public interface EbookMapper extends BaseMapper<Ebook> {

    void increaseViewCount(Long ebookId);
}
