package com.jw.wenku.mapper;

import com.jw.wenku.entity.EbookSnapshot;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jw.wenku.resp.StatisticResp;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author JW
 * @since 2026-06-16
 */
public interface EbookSnapshotMapper extends BaseMapper<EbookSnapshot> {

    void genSnapshot();

    List<StatisticResp> getStatistic();

    List<StatisticResp> get30Statistic();
}
