package com.jw.wenku.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jw.wenku.entity.User;

public interface UserMapper extends BaseMapper<User> {
}
