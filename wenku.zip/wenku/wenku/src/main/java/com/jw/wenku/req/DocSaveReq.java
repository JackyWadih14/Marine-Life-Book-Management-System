package com.jw.wenku.req;

import lombok.Data;
import lombok.ToString;

import javax.validation.constraints.NotNull;

@Data
@ToString
public class DocSaveReq {
    private Long id;

    private Long ebookId;

    private Long parent;

    @NotNull(message = "【名称】不能为空")
    private String name;

    private Integer sort;

    private Integer viewCount;

    private Integer voteCount;

    private String content;
}