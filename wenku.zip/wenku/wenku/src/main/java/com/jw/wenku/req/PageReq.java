package com.jw.wenku.req;

import lombok.Data;
import lombok.ToString;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

@Data
@ToString
public class PageReq {
    @NotNull(message = "【页码】不能为空")
    @Min(value = 1, message = "【页码】最小值为 1")
    private Integer page = 1;

    @NotNull(message = "【每页条数】不能为空")
    @Min(value = 1, message = "【每页条数】最小值为 1")
    @Max(value = 1000, message = "【每页条数】不能超过1000")
    private Integer size = 10;
}