package com.jw.wenku.resp;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CommonResp<T> {
    private boolean success = true;
    private  String message;
    private T content;

    public CommonResp( ) { }
}
