package com.jw.wenku.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jw.wenku.entity.Category;
import com.jw.wenku.req.CategoryQueryReq;
import com.jw.wenku.req.CategorySaveReq;
import com.jw.wenku.resp.CategoryQueryResp;
import com.jw.wenku.resp.PageResp;

import java.util.List;

public interface ICategoryService extends IService<Category> {

    /**
     * 分页查询分类列表
     */
    PageResp<CategoryQueryResp> listByname(CategoryQueryReq req);

    /**
     * 新增或更新分类
     */
    void save(CategorySaveReq req);

    /**
     * 删除分类（根据ID）
     */
    void delete(Long id);

    /**
     * 查询所有分类（按 sort 排序）
     */
    List<CategoryQueryResp> all();
}