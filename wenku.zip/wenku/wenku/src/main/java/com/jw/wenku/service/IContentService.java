package com.jw.wenku.service;

import com.jw.wenku.entity.Content;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author JW
 * @since 2026-06-16
 */
public interface IContentService extends IService<Content> {

    /**
     * 根据ID查询文档内容
     */
    String findContent(Long id);
}