package com.jw.wenku.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jw.wenku.entity.Doc;
import com.jw.wenku.req.DocQueryReq;
import com.jw.wenku.req.DocSaveReq;
import com.jw.wenku.resp.DocQueryResp;
import com.jw.wenku.resp.PageResp;

import java.util.List;

public interface IDocService extends IService<Doc> {

    /**
     * 分页查询文档列表
     */
    PageResp<DocQueryResp> listByname(DocQueryReq req);

    /**
     * 新增或更新文档
     */
    void save(DocSaveReq req);

    /**
     * 删除文档（根据ID）
     */
    void delete(Long id);

    /**
     * 查询所有文档（按 sort 排序）
     */
    List<DocQueryResp> all();

    void delete(List<Long> ids);

    List<DocQueryResp> allbyEbookId(Long ebookId);

    void vote(Long id);

    DocQueryResp info(Long id);

    void updateEbookInfo();
}