package com.jw.wenku.service;

import com.jw.wenku.entity.Ebook;
import com.baomidou.mybatisplus.extension.service.IService;
import com.jw.wenku.req.EbookQueryReq;
import com.jw.wenku.req.EbookSaveReq;
import com.jw.wenku.resp.EbookQueryResp;
import com.jw.wenku.resp.PageResp;

import java.util.List;

/**
 * <p>
 * 电子书 服务类
 * </p>
 *
 * @author JW
 * @since 2026-06-16
 */
public interface IEbookService extends IService<Ebook> {
    PageResp<EbookQueryResp> getBookList(EbookQueryReq req);
    void save(EbookSaveReq req);  // 新增
}
