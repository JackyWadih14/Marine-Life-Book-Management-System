package com.jw.wenku.service;

import com.jw.wenku.entity.EbookSnapshot;
import com.baomidou.mybatisplus.extension.service.IService;
import com.jw.wenku.resp.StatisticResp;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author JW
 * @since 2026-06-16
 */
public interface IEbookSnapshotService extends IService<EbookSnapshot> {

    void genSnapshot();

    List<StatisticResp> getStatistic();

    List<StatisticResp> get30Statistic();
}
