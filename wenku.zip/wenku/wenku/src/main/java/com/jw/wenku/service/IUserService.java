package com.jw.wenku.service;

import com.jw.wenku.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;
import com.jw.wenku.req.UserLoginReq;
import com.jw.wenku.req.UserQueryReq;
import com.jw.wenku.req.UserResetPasswordReq;
import com.jw.wenku.req.UserSaveReq;
import com.jw.wenku.resp.PageResp;
import com.jw.wenku.resp.UserLoginResp;
import com.jw.wenku.resp.UserQueryResp;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author JW
 * @since 2026-06-16
 */
public interface IUserService extends IService<User> {

    PageResp<UserQueryResp> listByname(UserQueryReq req);

    void delete(Long id);

    void save(UserSaveReq req);

    void resetPassword(UserResetPasswordReq req);

    UserLoginResp login(UserLoginReq req);
}
