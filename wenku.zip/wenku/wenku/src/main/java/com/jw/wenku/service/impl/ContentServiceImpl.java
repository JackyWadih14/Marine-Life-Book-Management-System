package com.jw.wenku.service.impl;

import com.jw.wenku.entity.Content;
import com.jw.wenku.mapper.ContentMapper;
import com.jw.wenku.mapper.DocMapper;
import com.jw.wenku.service.IContentService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author JW
 * @since 2026-06-16
 */
@Service
public class ContentServiceImpl extends ServiceImpl<ContentMapper, Content> implements IContentService {

    @Autowired
    DocMapper docMapper;

    @Override
    public String findContent(Long id) {
        Content content = this.baseMapper.selectById(id);
        docMapper.increaseViewCount(id);
        if(content !=null){
            return content.getContent();
        }
        return null;
    }
}