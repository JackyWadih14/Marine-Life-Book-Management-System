package com.jw.wenku.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jw.wenku.entity.Content;
import com.jw.wenku.entity.Doc;
import com.jw.wenku.exception.BusinessException;
import com.jw.wenku.exception.BusinessExceptionCode;
import com.jw.wenku.mapper.DocMapper;
import com.jw.wenku.mapper.EbookMapper;
import com.jw.wenku.req.DocQueryReq;
import com.jw.wenku.req.DocSaveReq;
import com.jw.wenku.resp.DocQueryResp;
import com.jw.wenku.resp.PageResp;
import com.jw.wenku.service.IContentService;
import com.jw.wenku.service.IDocService;
import com.jw.wenku.util.CopyUtil;
import com.jw.wenku.util.RedisUtil;
import com.jw.wenku.util.RequestContext;
import com.jw.wenku.util.SnowFlake;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.rocketmq.spring.core.RocketMQTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * <p>
 * 文档 服务实现类
 * </p>
 *
 * @author JW
 * @since 2026-06-16
 */
@Service
public class DocServiceImpl extends ServiceImpl<DocMapper, Doc> implements IDocService {

    private static final Logger LOG = LoggerFactory.getLogger(DocServiceImpl.class);

    @Autowired
    private SnowFlake snowFlake;

    @Autowired
    private IContentService contentService;

    @Autowired
    private EbookMapper ebookMapper;

    @Autowired
    private RedisUtil redisUtil;

    @Autowired
    private RocketMQTemplate rocketMQTemplate;   // 注入 RocketMQ 模板

    // ---------- 分页查询 ----------
    @Override
    public PageResp<DocQueryResp> listByname(DocQueryReq req) {
        QueryWrapper<Doc> queryWrapper = new QueryWrapper<>();
        queryWrapper.like(StringUtils.isNotBlank(req.getName()), "name", req.getName());

        Page<Doc> page = new Page<>(req.getPage(), req.getSize());
        page = this.baseMapper.selectPage(page, queryWrapper);

        List<DocQueryResp> resps = CopyUtil.copyList(page.getRecords(), DocQueryResp.class);
        PageResp<DocQueryResp> pageResp = new PageResp<>();
        pageResp.setList(resps);
        pageResp.setTotal(page.getTotal());
        return pageResp;
    }

    // ---------- 新增 / 更新（事务） ----------
    @Override
    @Transactional
    public void save(DocSaveReq req) {
        Doc doc = CopyUtil.copy(req, Doc.class);
        Content content = CopyUtil.copy(req, Content.class);

        if (ObjectUtils.isEmpty(req.getId())) {
            // 新增
            long id = snowFlake.nextId();
            doc.setId(id);
            doc.setViewCount(0);
            doc.setVoteCount(0);
            this.baseMapper.insert(doc);

            content.setId(id);
            contentService.save(content);
        } else {
            // 更新
            this.baseMapper.updateById(doc);
            boolean updated = contentService.updateById(content);
            if (!updated) {
                contentService.save(content);
            }
        }
    }

    // ---------- 删除单个 ----------
    @Override
    public void delete(Long id) {
        this.baseMapper.deleteById(id);
    }

    // ---------- 批量删除 ----------
    @Override
    public void delete(List<Long> ids) {
        this.baseMapper.deleteBatchIds(ids);
    }

    // ---------- 查询所有（树形结构） ----------
    @Override
    public List<DocQueryResp> all() {
        List<Doc> docs = this.baseMapper.selectList(new QueryWrapper<Doc>().orderByAsc("sort"));
        return CopyUtil.copyList(docs, DocQueryResp.class);
    }

    // ---------- 根据电子书ID查询文档列表（阅读数+1） ----------
    @Override
    public List<DocQueryResp> allbyEbookId(Long ebookId) {
        // 增加电子书阅读数
        ebookMapper.increaseViewCount(ebookId);

        QueryWrapper<Doc> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("ebook_id", ebookId).orderByAsc("sort");
        List<Doc> docList = this.baseMapper.selectList(queryWrapper);

        return CopyUtil.copyList(docList, DocQueryResp.class);
    }

    // ---------- 点赞（Redis 防重复 + RocketMQ 异步通知） ----------
    @Override
    public void vote(Long id) {
        String clientIp = RequestContext.getRemoteAddr();
        String key = "DOC_VOTE_" + id + "_" + clientIp;

        // 检查是否已点赞（24小时有效）
        if (redisUtil.validateRepeat(key, 3600 * 24)) {
            // 点赞
            this.baseMapper.increaseVoteCount(id);
            LOG.info("文档点赞成功，docId: {}, ip: {}", id, clientIp);

            // 查询文档名称
            Doc doc = this.baseMapper.selectById(id);
            if (doc != null) {
                // 发送 RocketMQ 消息（异步通知）
                String message = "【" + doc.getName() + "】被点赞！";
                rocketMQTemplate.convertAndSend("VOTE_TOPIC", message);
                LOG.info("RocketMQ 消息已发送：{}", message);
            }
        } else {
            LOG.warn("重复点赞，docId: {}, ip: {}", id, clientIp);
            throw new BusinessException(BusinessExceptionCode.VOTE_REPEAT);
        }
    }

    // ---------- 获取文档基本信息（含投票数） ----------
    @Override
    public DocQueryResp info(Long id) {
        Doc doc = this.baseMapper.selectById(id);
        return CopyUtil.copy(doc, DocQueryResp.class);
    }

    // ---------- 定时更新电子书信息（统计文档数、阅读数、点赞数） ----------
    @Override
    public void updateEbookInfo() {
        this.baseMapper.updateEbookInfo();
    }
}