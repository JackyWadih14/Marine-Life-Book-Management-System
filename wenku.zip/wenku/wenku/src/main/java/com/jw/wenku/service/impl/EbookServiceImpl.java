package com.jw.wenku.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jw.wenku.entity.Ebook;
import com.jw.wenku.mapper.EbookMapper;
import com.jw.wenku.req.EbookQueryReq;
import com.jw.wenku.req.EbookSaveReq;
import com.jw.wenku.resp.EbookQueryResp;
import com.jw.wenku.resp.PageResp;
import com.jw.wenku.service.IEbookService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jw.wenku.util.CopyUtil;
import com.jw.wenku.util.SnowFlake;  // 确保导入正确的包路径
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 电子书 服务实现类
 * </p>
 *
 * @author JW
 * @since 2026-06-16
 */

@Service
public class EbookServiceImpl extends ServiceImpl<EbookMapper, Ebook> implements IEbookService {

    @Autowired
    private EbookMapper ebookMapper;

    @Autowired
    private SnowFlake snowFlake;   // 注入雪花算法工具类

    @Override
    public PageResp<EbookQueryResp> getBookList(EbookQueryReq req) {
        // 兜底处理：防止 page/size 为 0 或 null 导致 MyBatis-Plus 分页插件只返回 count
        int currentPage = req.getPage() == null || req.getPage() < 1 ? 1 : req.getPage();
        int pageSize = req.getSize() == null || req.getSize() < 1 ? 10 : req.getSize();

        QueryWrapper<Ebook> queryWrapper = new QueryWrapper<>();
        queryWrapper.like(StringUtils.isNotBlank(req.getName()), "name", req.getName());
        queryWrapper.eq(ObjectUtils.isNotEmpty(req.getCategoryId2()), "category2_id", req.getCategoryId2());

        Page<Ebook> page = new Page<>(currentPage, pageSize);
        page = this.baseMapper.selectPage(page, queryWrapper);
        // ...

        List<EbookQueryResp> resps = CopyUtil.copyList(page.getRecords(), EbookQueryResp.class);
        PageResp<EbookQueryResp> pageResp = new PageResp<>();
        pageResp.setList(resps);
        pageResp.setTotal(page.getTotal());
        return pageResp;
    }

    /**
     * 新增或更新电子书（使用雪花算法生成ID）
     * @param req 保存请求对象
     */
    @Override
    public void save(EbookSaveReq req) {
        Ebook ebook = CopyUtil.copy(req, Ebook.class);
        if (ObjectUtils.isEmpty(req.getId())) {
            // 新增：雪花算法生成ID
            long id = snowFlake.nextId();
            ebook.setId(id);
            this.baseMapper.insert(ebook);
        } else {
            // 更新
            this.baseMapper.updateById(ebook);
        }
    }
}