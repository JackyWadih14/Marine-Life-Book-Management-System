package com.jw.wenku.service.impl;

import com.jw.wenku.entity.EbookSnapshot;
import com.jw.wenku.mapper.EbookSnapshotMapper;
import com.jw.wenku.resp.StatisticResp;
import com.jw.wenku.service.IEbookSnapshotService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author JW
 * @since 2026-06-16
 */
@Service
public class EbookSnapshotServiceImpl extends ServiceImpl<EbookSnapshotMapper, EbookSnapshot> implements IEbookSnapshotService {

    @Override
    public void genSnapshot() {
        this.baseMapper.genSnapshot();
    }

    @Override
    public List<StatisticResp> getStatistic() {
        return  this.baseMapper.getStatistic();
    }

    @Override
    public List<StatisticResp> get30Statistic() {
        return this.baseMapper.get30Statistic();
    }

}
