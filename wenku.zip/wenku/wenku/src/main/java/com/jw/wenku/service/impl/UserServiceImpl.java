package com.jw.wenku.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jw.wenku.entity.User;
import com.jw.wenku.exception.BusinessException;
import com.jw.wenku.exception.BusinessExceptionCode;
import com.jw.wenku.mapper.UserMapper;
import com.jw.wenku.req.UserLoginReq;
import com.jw.wenku.req.UserQueryReq;
import com.jw.wenku.req.UserResetPasswordReq;
import com.jw.wenku.req.UserSaveReq;
import com.jw.wenku.resp.PageResp;
import com.jw.wenku.resp.UserLoginResp;
import com.jw.wenku.resp.UserQueryResp;
import com.jw.wenku.service.IUserService;
import com.jw.wenku.util.CopyUtil;
import com.jw.wenku.util.SnowFlake;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;

import java.util.List;

/**
 * <p>
 * 用户 服务实现类
 * </p>
 *
 * @author JW
 * @since 2026-06-16
 */
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements IUserService {

    private static final Logger LOG = LoggerFactory.getLogger(UserServiceImpl.class);

    @Autowired
    private SnowFlake snowFlake;

    @Override
    public PageResp<UserQueryResp> listByname(UserQueryReq req) {
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();

        // 按名称或登录名模糊查询（二选一或同时查询）
        String name = req.getName();
        String loginName = req.getLoginName();
        if (StringUtils.isNotBlank(name) && StringUtils.isNotBlank(loginName)) {
            queryWrapper.like("name", name).or().like("login_name", loginName);
        } else if (StringUtils.isNotBlank(name)) {
            queryWrapper.like("name", name);
        } else if (StringUtils.isNotBlank(loginName)) {
            queryWrapper.like("login_name", loginName);
        }

        Page<User> page = new Page<>(req.getPage(), req.getSize());
        page = this.baseMapper.selectPage(page, queryWrapper);

        List<UserQueryResp> resps = CopyUtil.copyList(page.getRecords(), UserQueryResp.class);
        PageResp<UserQueryResp> pageResp = new PageResp<>();
        pageResp.setList(resps);
        pageResp.setTotal(page.getTotal());
        return pageResp;
    }

    @Override
    public void save(UserSaveReq req) {
        User user = CopyUtil.copy(req, User.class);
        // 密码 MD5 加密
        user.setPassword(DigestUtils.md5DigestAsHex(req.getPassword().getBytes()));
        if (ObjectUtils.isEmpty(req.getId())) {
            // 新增：检查登录名是否已存在
            User existUser = this.baseMapper.selectOne(
                    new QueryWrapper<User>().eq("login_name", req.getLoginName())
            );
            if (ObjectUtils.isNotEmpty(existUser)) {
                throw new BusinessException(BusinessExceptionCode.USER_LOGIN_NAME_EXIST);
            }
            // 新增：生成 ID
            long id = snowFlake.nextId();
            user.setId(id);
            this.baseMapper.insert(user);
        } else {
            // 更新：防止登录名被修改
            user.setLoginName(null);
            this.baseMapper.updateById(user);
        }
    }

    @Override
    public void delete(Long id) {
        this.baseMapper.deleteById(id);
    }

    @Override
    public void resetPassword(UserResetPasswordReq req) {
        User user = CopyUtil.copy(req, User.class);
        this.baseMapper.updateById(user);
    }

    @Override
    public UserLoginResp login(UserLoginReq req) {
        // 1. 根据用户名查询用户信息
        User user = this.baseMapper.selectOne(
                new QueryWrapper<User>().eq("login_name", req.getLoginName())
        );
        if (ObjectUtils.isEmpty(user)) {
            // 用户名不存在
            LOG.info("用户名不存在, {}", req.getLoginName());
            throw new BusinessException(BusinessExceptionCode.LOGIN_USER_ERROR);
        } else {
            // 2. 比较密码（已由 Controller 层 MD5 加密）
            if (user.getPassword().equals(req.getPassword())) {
                // 登录成功
                return CopyUtil.copy(user, UserLoginResp.class);
            } else {
                // 密码错误
                LOG.info("密码错误, 输入密码：{}, 数据库密码：{}", req.getPassword(), user.getPassword());
                throw new BusinessException(BusinessExceptionCode.LOGIN_USER_ERROR);
            }
        }
    }
}