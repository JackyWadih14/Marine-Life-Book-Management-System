package com.jw.wenku.websocket;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.websocket.*;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;

/**
 * WebSocket 服务端
 * 路径：/ws/{token}，token 用于标识客户端身份
 */
@Component
@ServerEndpoint("/ws/{token}")
public class WebSocketServer {

    private static final Logger LOG = LoggerFactory.getLogger(WebSocketServer.class);

    // 存储所有客户端 Session（线程安全）
    private static final ConcurrentHashMap<String, Session> SESSION_MAP = new ConcurrentHashMap<>();

    // 当前客户端的 token
    private String token;

    /**
     * 连接建立成功时调用
     */
    @OnOpen
    public void onOpen(Session session, @PathParam("token") String token) {
        this.token = token;
        // 如果已存在该 token 的连接，先关闭旧连接（可选）
        Session oldSession = SESSION_MAP.put(token, session);
        if (oldSession != null && oldSession.isOpen()) {
            try {
                oldSession.close();
                LOG.info("替换旧连接，token：{}", token);
            } catch (IOException e) {
                LOG.error("关闭旧连接异常", e);
            }
        }
        LOG.info("新连接：token：{}，session id：{}，当前连接数：{}", token, session.getId(), SESSION_MAP.size());
    }

    /**
     * 连接关闭时调用
     */
    @OnClose
    public void onClose(Session session) {
        SESSION_MAP.remove(this.token);
        LOG.info("连接关闭，token：{}，session id：{}，当前连接数：{}", this.token, session.getId(), SESSION_MAP.size());
    }

    /**
     * 收到客户端消息时调用
     */
    @OnMessage
    public void onMessage(String message, Session session) {
        LOG.info("收到消息，token：{}，内容：{}", token, message);
        // 可在此处根据业务处理消息
        // 例如：广播给所有客户端或回复特定客户端
    }

    /**
     * 连接发生错误时调用
     */
    @OnError
    public void onError(Session session, Throwable error) {
        LOG.error("WebSocket 错误，token：{}", token, error);
    }

    /**
     * 群发消息（广播）
     */
    public void sendInfo(String message) {
        if (SESSION_MAP.isEmpty()) {
            LOG.warn("无在线客户端，广播消息被忽略");
            return;
        }
        for (String key : SESSION_MAP.keySet()) {
            Session session = SESSION_MAP.get(key);
            if (session != null && session.isOpen()) {
                try {
                    session.getBasicRemote().sendText(message);
                    LOG.info("推送消息成功，token：{}", key);
                } catch (IOException e) {
                    LOG.error("推送消息失败，token：{}，内容：{}", key, message, e);
                }
            } else {
                // 清理无效 session
                SESSION_MAP.remove(key);
                LOG.warn("移除无效连接，token：{}", key);
            }
        }
    }

    /**
     * 单播消息（推送给指定 token）
     */
    public void sendTo(String token, String message) {
        Session session = SESSION_MAP.get(token);
        if (session == null || !session.isOpen()) {
            LOG.warn("目标客户端不在线或连接已关闭，token：{}", token);
            return;
        }
        try {
            session.getBasicRemote().sendText(message);
            LOG.info("单播消息成功，token：{}", token);
        } catch (IOException e) {
            LOG.error("单播消息失败，token：{}，内容：{}", token, message, e);
        }
    }

    /**
     * 获取当前在线客户端数量
     */
    public static int getOnlineCount() {
        return SESSION_MAP.size();
    }
}