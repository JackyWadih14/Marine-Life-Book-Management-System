package com.jw.wenku;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.generator.FastAutoGenerator;
import com.baomidou.mybatisplus.generator.config.OutputFile;
import com.jw.wenku.entity.User;
import com.jw.wenku.mapper.UserMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Collections;
import java.util.List;

@SpringBootTest
public class WenKuApplicationTests {


    @Test
    public void contextLoads() {
        String url = "jdbc:mysql://localhost:3306/haiyang?useUnicode=true&characterEncoding=utf-8&useSSL=false&serverTimezone=Asia/Shanghai";

        FastAutoGenerator.create(url, "root", "123456")
                .globalConfig(builder -> {
                    builder.author("JW") // 设置作者
                            //.enableSwagger() // 开启 swagger 模式
                            .fileOverride() // 覆盖已生成文件
                            .outputDir("C://Users//Tang//Desktop//2026realdo//wenku//wenku//src//main//java"); // 指定输出目录
                })
                .packageConfig(builder -> {
                    builder.parent("com.jw") // 设置父包名
                            .moduleName("wenku") // 设置父包模块名
                            .pathInfo(Collections.singletonMap(OutputFile.xml, "C://Users//Tang//Desktop//2026realdo//wenku//wenku//src//main//resources//mapper")); // 设置mapperXml生成路径
                })
                .strategyConfig(builder -> {
                    builder.addInclude("category,content,doc,ebook,ebook_snapshot,user"); // 设置需要生成的表名
                    //.addTablePrefix("t_", "c_"); // 设置过滤表前缀
                })
                //.templateEngine(new FreemarkerTemplateEngine()) // 使用Freemarker引擎模板，默认的是Velocity引擎模板
                .execute();
    }

    @Autowired
    private UserMapper userMapper;

    @Test
    public void queryUser(){
        List<User> users = userMapper.selectList(new QueryWrapper<>());
        System.out.println(users);
    }
}
